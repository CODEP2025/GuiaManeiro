
import csv
from pathlib import Path
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils.text import slugify
from guia.models import Procedimento, Eixo

FIELDS_MAP = {
    "procedimento": "titulo",
    "setor_responsavel": "setor_responsavel",
    "publico_alvo": "publico_alvo",
    "descricao": "descricao",
    "documentos_exigidos": "documentos_exigidos",
    "procedimentos": "procedimentos",
    "legislacao": "legislacao",
    "observacoes": "observacoes",
    "link_sei": "link_sei",
}

class Command(BaseCommand):
    help = ("Importa/atualiza Procedimentos a partir de um CSV. Use --eixo 'Nome do Eixo' para atribuir o mesmo eixo.")

    def add_arguments(self, parser):
        parser.add_argument("csv_path", type=str, help="Caminho do CSV")
        parser.add_argument("--eixo", dest="eixo_nome", default="Benefícios e Direitos",
                            help="Nome do Eixo para todas as linhas.")

    @transaction.atomic
    def handle(self, *args, **options):
        csv_path = Path(options["csv_path"])
        if not csv_path.exists():
            raise CommandError(f"Arquivo não encontrado: {csv_path}")

        eixo_nome = (options["eixo_nome"] or "").strip() or "Benefícios e Direitos"
        eixo_obj, _ = Eixo.objects.get_or_create(nome=eixo_nome)

        text = csv_path.read_text(encoding="utf-8-sig")
        lines = [ln for ln in text.splitlines() if ln.strip()]
        if not lines:
            raise CommandError("CSV sem conteúdo.")

        try:
            dialect = csv.Sniffer().sniff("\n".join(lines[:5]), delimiters=",;|\t")
        except Exception:
            class _D: delimiter = ","
            dialect = _D()

        reader = csv.DictReader(lines, delimiter=dialect.delimiter)
        headers = [h.strip().lower() for h in (reader.fieldnames or [])]
        if "procedimento" not in headers:
            raise CommandError("CSV sem cabeçalho 'procedimento'.")

        created = updated = 0
        for row in reader:
            data = {}
            for csv_field, model_field in FIELDS_MAP.items():
                if csv_field in row:
                    data[model_field] = (row.get(csv_field) or "").strip()

            titulo = data.get("titulo")
            if not titulo:
                self.stdout.write(self.style.WARNING("Linha ignorada: sem 'procedimento/titulo'."))
                continue

            data["eixo"] = eixo_obj
            if not data.get("slug"):
                data["slug"] = slugify(titulo)[:50]

            obj, was_created = Procedimento.objects.update_or_create(
                titulo=titulo,
                defaults=data,
            )
            created += int(was_created)
            updated += int(not was_created)

        self.stdout.write(self.style.SUCCESS(
            f"Importação concluída. Criados: {created} | Atualizados: {updated} | Eixo: {eixo_obj.nome}"
        ))
