
from django.shortcuts import render, get_object_or_404
from .models import Procedimento, Eixo

def home(request):
    eixo_id = request.GET.get("eixo")
    q = (request.GET.get("q") or "").strip()
    procedimentos = Procedimento.objects.all().select_related("eixo")
    if eixo_id:
        procedimentos = procedimentos.filter(eixo_id=eixo_id)
    if q:
        procedimentos = procedimentos.filter(titulo__icontains=q)
    return render(request, "guia/home.html", {
        "eixos": Eixo.objects.all(),
        "procedimentos": procedimentos[:50],
        "q": q,
        "eixo_id": eixo_id or "",
    })

def procedimento_detail(request, slug):
    procedimento = get_object_or_404(Procedimento, slug=slug)
    return render(request, "guia/procedimento_detail.html", {"procedimento": procedimento})
