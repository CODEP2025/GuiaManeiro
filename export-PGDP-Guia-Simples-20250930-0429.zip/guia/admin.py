
from django.contrib import admin
from django.db import models
from django.forms import Textarea
from .models import Eixo, Procedimento

@admin.register(Eixo)
class EixoAdmin(admin.ModelAdmin):
    search_fields = ["nome"]
    list_display = ["nome"]

@admin.register(Procedimento)
class ProcedimentoAdmin(admin.ModelAdmin):
    list_display = ["titulo", "eixo", "setor_responsavel"]
    list_filter = ["eixo", "setor_responsavel"]
    search_fields = ["titulo", "descricao", "publico_alvo", "legislacao"]
    prepopulated_fields = {"slug": ("titulo",)}
    fields = (
        "eixo","titulo","slug","setor_responsavel",
        "descricao","publico_alvo","documentos_exigidos",
        "procedimentos","legislacao","observacoes","link_sei",
    )
    formfield_overrides = {models.TextField: {"widget": Textarea(attrs={"rows": 5})}}
