
from django.db import models
from django.utils.text import slugify

class Eixo(models.Model):
    nome = models.CharField(max_length=120, unique=True)

    class Meta:
        verbose_name = "Eixo"
        verbose_name_plural = "Eixos"

    def __str__(self):
        return self.nome

class Procedimento(models.Model):
    eixo = models.ForeignKey(Eixo, on_delete=models.PROTECT, related_name="procedimentos")
    titulo = models.CharField(max_length=200, unique=True)
    slug = models.SlugField(unique=True, blank=True)
    setor_responsavel = models.CharField(max_length=120, default="PGDP")
    descricao = models.TextField(blank=True)
    publico_alvo = models.TextField(blank=True)
    documentos_exigidos = models.TextField(blank=True)
    procedimentos = models.TextField(blank=True)
    legislacao = models.TextField(blank=True)
    observacoes = models.TextField(blank=True)
    link_sei = models.URLField(blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.titulo)[:50]
        super().save(*args, **kwargs)

    def __str__(self):
        return self.titulo
